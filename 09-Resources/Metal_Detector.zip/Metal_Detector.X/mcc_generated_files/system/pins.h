/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RD0 aliases
#define RX_TRIS                 TRISDbits.TRISD0
#define RX_LAT                  LATDbits.LATD0
#define RX_PORT                 PORTDbits.RD0
#define RX_WPU                  WPUDbits.WPUD0
#define RX_OD                   ODCONDbits.ODCD0
#define RX_ANS                  ANSELDbits.ANSELD0
#define RX_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define RX_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define RX_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define RX_GetValue()           PORTDbits.RD0
#define RX_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define RX_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define RX_SetPullup()          do { WPUDbits.WPUD0 = 1; } while(0)
#define RX_ResetPullup()        do { WPUDbits.WPUD0 = 0; } while(0)
#define RX_SetPushPull()        do { ODCONDbits.ODCD0 = 0; } while(0)
#define RX_SetOpenDrain()       do { ODCONDbits.ODCD0 = 1; } while(0)
#define RX_SetAnalogMode()      do { ANSELDbits.ANSELD0 = 1; } while(0)
#define RX_SetDigitalMode()     do { ANSELDbits.ANSELD0 = 0; } while(0)

// get/set RD1 aliases
#define TX_TRIS                 TRISDbits.TRISD1
#define TX_LAT                  LATDbits.LATD1
#define TX_PORT                 PORTDbits.RD1
#define TX_WPU                  WPUDbits.WPUD1
#define TX_OD                   ODCONDbits.ODCD1
#define TX_ANS                  ANSELDbits.ANSELD1
#define TX_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define TX_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define TX_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define TX_GetValue()           PORTDbits.RD1
#define TX_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define TX_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define TX_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define TX_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define TX_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define TX_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define TX_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define TX_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

// get/set RD6 aliases
#define IO_RD6_TRIS                 TRISDbits.TRISD6
#define IO_RD6_LAT                  LATDbits.LATD6
#define IO_RD6_PORT                 PORTDbits.RD6
#define IO_RD6_WPU                  WPUDbits.WPUD6
#define IO_RD6_OD                   ODCONDbits.ODCD6
#define IO_RD6_ANS                  ANSELDbits.ANSELD6
#define IO_RD6_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define IO_RD6_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define IO_RD6_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define IO_RD6_GetValue()           PORTDbits.RD6
#define IO_RD6_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define IO_RD6_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)
#define IO_RD6_SetPullup()          do { WPUDbits.WPUD6 = 1; } while(0)
#define IO_RD6_ResetPullup()        do { WPUDbits.WPUD6 = 0; } while(0)
#define IO_RD6_SetPushPull()        do { ODCONDbits.ODCD6 = 0; } while(0)
#define IO_RD6_SetOpenDrain()       do { ODCONDbits.ODCD6 = 1; } while(0)
#define IO_RD6_SetAnalogMode()      do { ANSELDbits.ANSELD6 = 1; } while(0)
#define IO_RD6_SetDigitalMode()     do { ANSELDbits.ANSELD6 = 0; } while(0)

// get/set RE0 aliases
#define Button_TRIS                 TRISEbits.TRISE0
#define Button_LAT                  LATEbits.LATE0
#define Button_PORT                 PORTEbits.RE0
#define Button_WPU                  WPUEbits.WPUE0
#define Button_OD                   ODCONEbits.ODCE0
#define Button_ANS                  ANSELEbits.ANSELE0
#define Button_SetHigh()            do { LATEbits.LATE0 = 1; } while(0)
#define Button_SetLow()             do { LATEbits.LATE0 = 0; } while(0)
#define Button_Toggle()             do { LATEbits.LATE0 = ~LATEbits.LATE0; } while(0)
#define Button_GetValue()           PORTEbits.RE0
#define Button_SetDigitalInput()    do { TRISEbits.TRISE0 = 1; } while(0)
#define Button_SetDigitalOutput()   do { TRISEbits.TRISE0 = 0; } while(0)
#define Button_SetPullup()          do { WPUEbits.WPUE0 = 1; } while(0)
#define Button_ResetPullup()        do { WPUEbits.WPUE0 = 0; } while(0)
#define Button_SetPushPull()        do { ODCONEbits.ODCE0 = 0; } while(0)
#define Button_SetOpenDrain()       do { ODCONEbits.ODCE0 = 1; } while(0)
#define Button_SetAnalogMode()      do { ANSELEbits.ANSELE0 = 1; } while(0)
#define Button_SetDigitalMode()     do { ANSELEbits.ANSELE0 = 0; } while(0)

// get/set RE1 aliases
#define LED_TRIS                 TRISEbits.TRISE1
#define LED_LAT                  LATEbits.LATE1
#define LED_PORT                 PORTEbits.RE1
#define LED_WPU                  WPUEbits.WPUE1
#define LED_OD                   ODCONEbits.ODCE1
#define LED_ANS                  ANSELEbits.ANSELE1
#define LED_SetHigh()            do { LATEbits.LATE1 = 1; } while(0)
#define LED_SetLow()             do { LATEbits.LATE1 = 0; } while(0)
#define LED_Toggle()             do { LATEbits.LATE1 = ~LATEbits.LATE1; } while(0)
#define LED_GetValue()           PORTEbits.RE1
#define LED_SetDigitalInput()    do { TRISEbits.TRISE1 = 1; } while(0)
#define LED_SetDigitalOutput()   do { TRISEbits.TRISE1 = 0; } while(0)
#define LED_SetPullup()          do { WPUEbits.WPUE1 = 1; } while(0)
#define LED_ResetPullup()        do { WPUEbits.WPUE1 = 0; } while(0)
#define LED_SetPushPull()        do { ODCONEbits.ODCE1 = 0; } while(0)
#define LED_SetOpenDrain()       do { ODCONEbits.ODCE1 = 1; } while(0)
#define LED_SetAnalogMode()      do { ANSELEbits.ANSELE1 = 1; } while(0)
#define LED_SetDigitalMode()     do { ANSELEbits.ANSELE1 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/