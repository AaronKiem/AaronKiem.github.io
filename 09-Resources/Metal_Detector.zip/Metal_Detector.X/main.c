#include "mcc_generated_files/system/system.h"
#include <xc.h>
#include <stdint.h>
#include <stdbool.h>

#define APP_RX_MAX 96U

static char appRxBuffer[APP_RX_MAX];
static uint8_t appRxIndex = 0U;
static uint8_t appFrameState = 0U;

/* ---------------- UART helpers ---------------- */

static void APP_UART_WriteChar(char c)
{
    while (!UART2_IsTxReady())
    {
        ;
    }
    UART2_Write((uint8_t)c);
}

static void APP_UART_WriteString(const char *s)
{
    while (*s != '\0')
    {
        APP_UART_WriteChar(*s++);
    }
}

static void APP_ForwardUnchanged(const char *payload)
{
    APP_UART_WriteChar('A');
    APP_UART_WriteChar('Z');
    APP_UART_WriteString(payload);
    APP_UART_WriteChar('Y');
    APP_UART_WriteChar('B');
}

/* ---------------- Local hardware helpers ---------------- */

static void APP_LED_On(void)
{
    LED_SetHigh();
}

static void APP_LED_Off(void)
{
    LED_SetLow();
}

static void APP_LED_Toggle(void)
{
    if (LED_GetValue() != 0U)
    {
        APP_LED_Off();
    }
    else
    {
        APP_LED_On();
    }
}

static bool APP_ReadInductor(void)
{
    return (IO_RD6_GetValue() == 0U);
}

/* ---------------- Small helpers ---------------- */

static bool APP_BufferContains(const char *buf, const char *needle)
{
    uint8_t i;
    uint8_t j;

    if (needle[0] == '\0')
    {
        return true;
    }

    for (i = 0U; buf[i] != '\0'; i++)
    {
        j = 0U;
        while ((buf[i + j] != '\0') && (needle[j] != '\0') && (buf[i + j] == needle[j]))
        {
            j++;
        }

        if (needle[j] == '\0')
        {
            return true;
        }
    }

    return false;
}

static bool APP_IsValidSystemId(char id)
{
    return (id == 'h') ||
           (id == 'c') ||
           (id == 'w') ||
           (id == 'P') ||
           (id == 'a') ||
           (id == 'm') ||
           (id == 't') ||
           (id == 'X');
}

/* ---------------- Read response ---------------- */

static void APP_SendMetalResponse(char destination, bool metalDetected)
{
    /* AZmhMD:S:T:YB or AZmhMD:S:F:YB */
    APP_UART_WriteChar('A');
    APP_UART_WriteChar('Z');
    APP_UART_WriteChar('m');
    APP_UART_WriteChar(destination);
    APP_UART_WriteChar('M');
    APP_UART_WriteChar('D');
    APP_UART_WriteChar(':');
    APP_UART_WriteChar('S');
    APP_UART_WriteChar(':');
    APP_UART_WriteChar(metalDetected ? 'T' : 'F');
    APP_UART_WriteChar(':');
    APP_UART_WriteChar('Y');
    APP_UART_WriteChar('B');
}

/* ---------------- Message handling ---------------- */

static void APP_HandleMessage(char *msg)
{
    /*
     * msg is the payload between AZ and YB.
     * Example:
     *   hmST:S:Start
     *   hmST:S:Stop
     *   hmMR:S:read
     */

    char source;
    char destination;

    if (msg[0] == '\0')
    {
        return;
    }

    if (msg[4] != ':' || msg[6] != ':')
    {
        return;
    }

    source = msg[0];
    destination = msg[1];

    if (!APP_IsValidSystemId(source) || !APP_IsValidSystemId(destination))
    {
        return;
    }

    /* Loopback/error */
    if (source == 'm')
    {
        return;
    }

    /* Not for me and not broadcast -> forward unchanged */
    if ((destination != 'm') && (destination != 'X'))
    {
        APP_ForwardUnchanged(msg);
        return;
    }

    /* LED Start/Stop: loose match, easier for testing */
    if (APP_BufferContains(msg, "Start"))
    {
        APP_LED_On();
    }
    else if (APP_BufferContains(msg, "Stop"))
    {
        APP_LED_Off();
    }

    /* Read request */
    if (APP_BufferContains(msg, "MR:S:read"))
    {
        bool metalDetected = APP_ReadInductor();
        APP_SendMetalResponse(source, metalDetected);
    }

    /* Broadcast gets forwarded after local handling */
    if (destination == 'X')
    {
        APP_ForwardUnchanged(msg);
    }
}

/* ---------------- RX frame collector ---------------- */

static void APP_CollectRxChar(char c)
{
    switch (appFrameState)
    {
        case 0U:
            if (c == 'A')
            {
                appFrameState = 1U;
            }
            break;

        case 1U:
            if (c == 'Z')
            {
                appFrameState = 2U;
                appRxIndex = 0U;
            }
            else if (c == 'A')
            {
                appFrameState = 1U;
            }
            else
            {
                appFrameState = 0U;
            }
            break;

        case 2U:
            if (c == 'Y')
            {
                appFrameState = 3U;
            }
            else
            {
                if (appRxIndex < (APP_RX_MAX - 1U))
                {
                    appRxBuffer[appRxIndex++] = c;
                }
                else
                {
                    appFrameState = 0U;
                    appRxIndex = 0U;
                }
            }
            break;

        case 3U:
            if (c == 'B')
            {
                appRxBuffer[appRxIndex] = '\0';
                APP_HandleMessage(appRxBuffer);
            }

            appFrameState = 0U;
            appRxIndex = 0U;
            break;

        default:
            appFrameState = 0U;
            appRxIndex = 0U;
            break;
    }
}

/* ---------------- UART task ---------------- */

static void APP_UART_Task(void)
{
    uart2_status_t status;

    while (UART2_IsRxReady())
    {
        status.status = UART2_ErrorGet();

        if (status.oerr != 0U)
        {
            UART2_ReceiveDisable();
            UART2_ReceiveEnable();
            continue;
        }

        if ((status.ferr != 0U) || (status.perr != 0U))
        {
            (void)UART2_Read();
            continue;
        }

        APP_CollectRxChar((char)UART2_Read());
    }
}

/* ---------------- Button task ---------------- */

static void APP_Button_Task(void)
{
    static uint8_t lastSample = 1U;
    static uint8_t stableState = 1U;
    static uint8_t debounceCount = 0U;

    uint8_t sample = (uint8_t)Button_GetValue();

    if (sample == lastSample)
    {
        if (debounceCount < 5U)
        {
            debounceCount++;
        }
    }
    else
    {
        debounceCount = 0U;
        lastSample = sample;
    }

    if ((debounceCount >= 5U) && (sample != stableState))
    {
        stableState = sample;
        debounceCount = 0U;
        APP_LED_Toggle();
    }
}

/* ---------------- Init ---------------- */

static void APP_Initialize(void)
{
    RX_SetDigitalInput();
    RX_SetDigitalMode();

    TX_SetDigitalOutput();
    TX_SetDigitalMode();

    IO_RD6_SetDigitalInput();
    IO_RD6_SetDigitalMode();

    Button_SetDigitalInput();
    Button_SetDigitalMode();
    Button_SetPullup();

    LED_SetDigitalOutput();
    LED_SetDigitalMode();
    LED_SetLow();

    UART2_Enable();
    UART2_ReceiveEnable();
    UART2_TransmitEnable();

    appRxIndex = 0U;
    appFrameState = 0U;
}

/* ---------------- Main ---------------- */

void main(void)
{
    SYSTEM_Initialize();
    APP_Initialize();

    INTERRUPT_GlobalInterruptEnable();

    while (1)
    {
        APP_UART_Task();
        APP_Button_Task();
    }
}